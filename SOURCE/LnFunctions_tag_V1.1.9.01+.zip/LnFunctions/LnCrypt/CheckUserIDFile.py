#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
import os

# -----------------------------------------------------------------------------
# - Eventuale file contentente UserID e Password.
# - La password se presente criptiamo essa altrimenti andiamo a console
# - La password verrà salvata codificata con in testa la codifica dello UserID.
# - Ad ogni partenza viene letta la password e se inizia correttamente con
# - lo UserID criptato allora vuol dire che va bene altrimenti la criptiamo.
# -
# - userId = user
# - password =
# -   Viene chiesta la password a console, criptata e salvata nel file
# -
# - userId = user
# - password = encrUser+Key-ecnrPsw+Key
# -   Viene decriptato lo user e confrontato con userid
# -
# ----------------------------------------------------------------------------

def checkUserIDFile(gv, fileName):
    LN          = gv.LN
    Prj         = gv.Prj
    calledBy    = LN.sys.calledBy
    # logger      = gv.LN.logger.setLogger(gv, package=__name__)
    logger      = gv.LN.logger.setLogger(gv, package=__name__)

    UserID, cryptedPassword, clearPassword = None, None, None
    sepString = 'Ln:+-:-+:Ln'

    if os.path.isfile(fileName):
        lines = LN.file.readAsciiFile(gv, fileName, lineCmntStr='#', stripLine=True, exitOnError=False, oneLine=False)

        for line in lines:
            if line == '': continue
            (key, val) = line.split('=', 1)
            if key.strip().lower() == 'userid':
                 UserID   = val.strip()
            elif key.strip().lower() == 'password':
               clearPassword = val.strip()

        if UserID:
            if not clearPassword:
                clearPassword = input('Please enter a password for monitoring userid [%s]: ' % (UserID) )

                # otteniamo il valore crypted dello userNAME
            token = clearPassword.split(sepString) # in teoria dovremmo avere 2 token (userid+password cripted)
            if len(token) == 2:
                cryptedUserID   = token[0]
                cryptedPassword = token[1]
                clearUserID = LN.crypt.XorDeCryptString(cryptedUserID, key=UserID)
                if clearUserID == UserID:                # Presumiamo che la password non sia cambiata
                    clearPassword = LN.crypt.XorDeCryptString(cryptedPassword, key=clearUserID)

                # Atrimenti la generiamo
            else:
                cryptedUserID   = LN.crypt.XorCryptString(UserID, key=UserID)
                cryptedPassword = LN.crypt.XorCryptString(clearPassword, key=UserID)
                logger.info('The hashed password for userID [%s] is: [%s]' % ( UserID, cryptedPassword))
                outLine = []
                outLine.append('userid   = %s' % (UserID) )
                outLine.append('password = %s%s%s' % (cryptedUserID, sepString, cryptedPassword))
                logger.info("Writing file: %s" % (fileName))
                LN.file.writeFile(gv, fileName, outLine, append=False, lineSep='\n')


    return UserID, clearPassword

#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
import os
import itertools

# -----------------------------------------------------------------------------
# - Eventuale file contentente UserID e Password.
# - La password se presente criptiamo essa altrimenti andiamo a console
# - La password verrà salvata codificata con in testa la codifica dello UserID.
# - Ad ogni partenza viene letta la password e se inizia correttamente con
# - lo UserID criptato allora vuol dire che va bene altrimenti la criptiamo.
# -
# - userId = user
# - password =
# -   Viene chiesta la password a console, criptata e salvata nel file
# -
# - userId = user
# - password = encrUser+Key-ecnrPsw+Key
# -   Viene decriptato lo user e confrontato con userid
# -
# ----------------------------------------------------------------------------
LnDummyOffset = 255

def LnCrypt_string(data, key):
    outStr = xor_string(data, key)

        # convertiamola in hexString (di 4 digit) per poterla salvare su file
    hexStr=''
    index=0
    for x in outStr:
        hexStr = hexStr + "%04X" % (ord(x)+LnDummyOffset*index)
        index += 1

    return hexStr


def LnDeCrypt_string(hexstring, key):
        # Splitting della stringa HEX in array (a+b+c+d indicano i digit 4 nel mio caso)
    it=iter(hexstring); hexArray = [a+b+c+d for a,b,c,d in zip(it, it, it, it)]

    # convert hex to econdedString
    encStr = ''
    index=0
    for c in hexArray:
        encStr += chr(int(c, 16)-LnDummyOffset*index)
        index += 1

    # decode String
    outStr = xor_string(encStr, key)
    return outStr


def xor_string(data, key):
    my_key  = key[::-1]             # Reverse della password
    outStr = ''.join(chr(ord(x) ^ ord(y)) for (x,y) in zip(data, itertools.cycle(my_key)))
    return outStr



def readFile(fname):
    with open(fname, "rb") as f: data = f.read()




################################################################################
# - M A I N
################################################################################
if __name__ == "__main__":
    my_data = "Hello. This is a secret message! How fun."
    my_key  = "firefly"

    # my_data = "Loreto"
    # my_key  = my_data[::-1] # Reverse della password

    # Do the actual encryption
    encHexStr = LnCrypt_string(my_data, key=my_key)
    print ("encHexStr:", encHexStr)

    decHexStr = LnDeCrypt_string(encHexStr, key=my_key)
    print ("decHexStr:", decHexStr)

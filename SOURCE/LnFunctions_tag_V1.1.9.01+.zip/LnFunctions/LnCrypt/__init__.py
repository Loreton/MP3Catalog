# outer __init__.py
# -*- coding: iso-8859-1 -*-


from .XorCryptString     import LnCrypt_string      as XorCryptString
from .XorCryptString     import LnDeCrypt_string    as XorDeCryptString

from .CheckUserIDFile    import checkUserIDFile

#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

import os
import shutil
import glob

# =================================================================
# - Copy multiple files to single file
#
# copyFile(gv, srcPATH="D:/temp/LnFile", srcFile='*',             dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)
# copyFile(gv, srcPATH="D:/temp/LnFile", srcFile='_*',            dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)
# copyFile(gv, srcPATH='D:/temp/LnFile', srcFile="LN_CopyDir.py", dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)
# =================================================================
def copyFile(gv, srcPATH=None, dstPATH=None, srcFile=None,  dstFile=None, createDir=False, exitOnError=False):
    logger      = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:{}]'.format(calledBy(1)))

    logger.debug( "srcPATH....: {}".format(srcPATH) )
    logger.debug( "srcFile....: {}".format(srcFile) )
    logger.debug( "dstPATH....: {}".format(dstPATH) )
    logger.debug( "dstFile....: {}".format(dstFile) )

    errMsg = None
    if not srcPATH:
        errMsg = "Missing source directory parameter"

    elif not os.path.isdir(srcPATH):
        errMsg = "Source directory doesn't exists [%s]" % (srcPATH)

    elif not srcFile:
        errMsg = "Missing source file parameter"

    if errMsg:
        logger.error(errMsg)
        if exitOnError:
            LN.sys.exit(gv, 9003, errMsg)
        print(LN.cERROR + errMsg)
        return False

    if '*' in srcFile: dstFile = None


        # =============================================
        # = Creazione del destination
        # =============================================
    if not os.path.isdir(dstPATH):
        msg = None

        if createDir:
            logger.info('creating directory:%s' % (dstPATH))

            try:
                os.makedirs(dstPATH)               # non posso farlo per il subTree
                logger.info("Directory {} has been created".format(dstPATH))

            except (IOError, os.error) as why:
                msg = "Error creating directory: {}".format(dstPATH, str(why))

        else:
            msg = "Directory [{}] doesn't exists. Use createDir=True if you want it to be created.".format(dstPATH)

        if msg:
            logger.warning(msg)
            if exitOnError: LN.sys.exit(gv, 9002, msg)
            return False


    if dstFile:
        dstPATH = os.path.join(dstPATH, dstFile)

    # print (os.path.join(srcPATH, srcFile))

    for filename in glob.glob(os.path.join(srcPATH, srcFile)):
        msg = 'copying {} -> {}'.format(filename, dstPATH)
        logger.info(msg)

        try:
            shutil.copy2(filename, dstPATH)

        except (IOError, os.error) as why:
            msg = "Can't COPY [%s/%s] to [%s]: %s" % (srcPATH, srcFile, dstPATH, str(why))
            logger.warning(msg)
            if exitOnError:
                LN.sys.exit(gv, 9002, msg)
            return False

    logger.debug('exiting - [called by:%s]' % (calledBy(1)))
    return True



################################################################################
# - M A I N
################################################################################
if __name__ == "__main__":

    copyFile(gv, srcPATH="D:/temp/LnFile", srcFile='*',             dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)
    copyFile(gv, srcPATH="D:/temp/LnFile", srcFile='_*',            dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)
    copyFile(gv, srcPATH='D:/temp/LnFile', srcFile="LN_CopyDir.py", dstPATH="D:/tmp/LnFileDest", dstFile='pippo.cfg', exitOnError=False)


#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# ##############################################################################################
# - delTree()
# - Per cancellare anche i file read-only
# -                                        by: Loreto Notarantonio (2014-01-05)
# ##############################################################################################
import os
import stat, shutil
import platform;    OpSys = platform.system()


def delTree(gv, topDir, exitOnError=False):
    logger  = gv.LN.logger.setLogger(gv, package=__name__)


    if OpSys.upper() == 'WINDOWS':
        shutil.rmtree(topDir)
        return

    else:
        try:
            for root, dirs, files in os.walk(topDir, topdown=False):
                for name in files:
                    filename = os.path.join(root, name)
                    logger.debug( "removing File: %s" % (filename))
                    os.chmod(filename, stat.S_IWUSR)
                    os.remove(filename)
                for name in dirs:
                    dirname = os.path.join(root, name)
                    os.rmdir(dirname)
                    logger.debug( "removing dir: %s" % (dirname))
            os.rmdir(topDir)
        except Exception as why:
            msg = "ERRORE durante la cancellazione della directory: {}\n{}".format(topDir, str(why))
            logger.error(msg)
            if exitOnError:
                sys.exit()
#!/usr/bin/python
# -*- coding: iso-8859-1 -*-

# metodo 1


# from htmlTable              import htmlTable
# from htmlTable              import htmlTable0
# from .htmlTable           import htmlTable
# from .htmlTable           import htmlTableCSS
# from .getJsonData            import getJsonData


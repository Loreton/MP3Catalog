#!/usr/bin/python -O
# -*- coding: latin-1 -*-
# -*- coding: iso-8859-1 -*-
# -O Optimize e non scrive il __debug__


# =========================================================================
# - Ritorna:
# =========================================================================
def stripItem(gv, LIST, stripValue=None):
    LN          = gv.LN
    logger      = gv.LN.logger
    calledBy    = gv.LN.sys.calledBy
    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    if stripValue:
        lista = [item.strip(stripValue) for item in LIST]
    else:
        lista = [item.strip() for item in LIST]


    return lista


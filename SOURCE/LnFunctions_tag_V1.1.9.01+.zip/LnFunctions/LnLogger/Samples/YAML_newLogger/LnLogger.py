# log_with_config.py
import logging
import logging.config

# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
#----------------------------------------------------------------------
import os, sys, imp


# #########################################################################################
# = dictLoadModule(cfgFile, logger=None)
# = Load di un modulo di configurazione (sintassi python) e lo ritorna in foramato dictionary
# = moduleName non deve contenere il '.'
# #########################################################################################
def loadModule(cfgFileName, moduleName=None):

    (scriptDir, FileName)   = os.path.split(os.path.abspath(cfgFileName))
    if not moduleName:
        moduleName = "MODULE_%s" % (FileName)
        moduleName = moduleName.replace('.', '_')

    print "Reading file: %s as ModuleName:%s" % (cfgFileName, moduleName)

    try:
        module = imp.load_source(moduleName, cfgFileName)
        dictID = module.__dict__
    except Exception, why:
        message = "Error loading file:%s - [%s]" % (cfgFileName, why)
        print message
        sys.exit()

    return dictID


def init(logConfigFileName, logDictName, loggerName):

        # carica il file di logConfig
    logConfig       = loadModule(logConfigFileName)
    dictLogConfig   = logConfig[logDictName]

        # Passiamolo come parametro al modulo di logging
    logging.config.dictConfig(dictLogConfig)

        # creiamo il nostro pointer
    logger      = logging.getLogger(loggerName)

    return logger

def main():
    """
    Based on http://docs.python.org/howto/logging.html#configuring-logging
             http://docs.python.org/2/library/logging.config.html#logging-config-api
             http://docs.python.org/2/library/logging.config.html#logging-config-dictschema
    """

    logConfigFileName   = 'LnLogger.conf'
    logDictName         = 'LnLoggerDict'
    loggerName          = 'exampleApp'

    logger              = init(logConfigFileName, logDictName, loggerName)

    logger.info("Program started")
    result = altroModulo.add(7, 8)
    logger.info("Done!")



if __name__ == "__main__":
    main()
    import altroModulo
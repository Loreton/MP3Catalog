# log_with_config.py
import logging
import logging.config

# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
#----------------------------------------------------------------------
import os, sys, imp


def init(logConfigFileName, loggerName):
        # carica il file di logConfig
    logging.config.fileConfig(logConfigFileName)

        # creiamo il nostro pointer
    logger      = logging.getLogger(loggerName)

    return logger

def main():
    """
    Based on http://docs.python.org/howto/logging.html#configuring-logging
             http://docs.python.org/2/library/logging.config.html#logging-config-api
             http://docs.python.org/2/library/logging.config.html#logging-config-dictschema
    """

    logConfigFileName   = 'LnLogger.ini'
    loggerName          = 'exampleApp'
    loggerName          = 'LnApp'

    logger              = init(logConfigFileName, loggerName)


    import LnModulo_02 as Modulo2
    logger.info("Program started")
    result = Modulo2.add1(7, 8)
    logger.info("Done!")


if __name__ == "__main__":
    main()
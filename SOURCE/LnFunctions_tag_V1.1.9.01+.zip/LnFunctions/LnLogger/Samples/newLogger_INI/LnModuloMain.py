# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
# otherMod.py
import sys; sys.dont_write_bytecode = True
import os

import LnModulo_02 as Modulo2
import LnModulo_03 as Modulo3

import LnLogger

# #####################################
# # Init LOG
# #####################################
logConfigFileName   = 'LnLogger.ini'
loggerName          = 'MainModule'
loggerName          = 'Appl01'


def main():
    # os.environ['LN_loggerName'] = loggerName
    logger = LnLogger.init(logConfigFileName, loggerName)

    logger.info("Program started")
    logger.info("calling modulo2")
    result = Modulo2.add1(7, 8)
    result = Modulo2.add2(7, 8)
    result = Modulo2.add3(7, 8)

    logger.info("calling prova")
    result = Modulo2.prova()

    logger.info("calling modulo3")
    result = Modulo3.add1(7, 8)
    result = Modulo3.add2(7, 8)
    result = Modulo3.add3(7, 8)
    logger.info("Done!")



if __name__ == "__main__":
    main()


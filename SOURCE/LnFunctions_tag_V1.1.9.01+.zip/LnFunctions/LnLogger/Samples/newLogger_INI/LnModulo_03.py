# http://www.blog.pythonlibrary.org/2012/08/02/python-101-an-intro-to-logging/
# otherMod2.py
import sys, os
import logging

loggerName = __name__
baseLoggerName = 'Appl01'
#----------------------------------------------------------------------
def add1(x, y):
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  'add2')
    logger = logging.getLogger(loggerName)
    # logger = logging.getLogger(loggerName)
    logger.info("added %s and %s to get %s" % (x, y, x+y))
    return x+y

def add2(x, y):
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  'add2')
    print (loggerName)
    logger = logging.getLogger(loggerName)
    logger.info("added %s and %s to get %s" % (x, y, x+y))
    return x+y

def add3(x, y):
    funcName = sys._getframe().f_code.co_name
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  funcName)
    print (loggerName)
    loggerName = "%s.%s.%s" % (baseLoggerName, __name__,  'add3')
    print (loggerName)
    logger = logging.getLogger(loggerName)
    logger.debug("added %s and %s to get %s" % (x, y, x+y))
    return x+y


#!/usr/bin/python -O
# -*- coding: iso-8859-15 -*-
# -O Optimize e non scrive il __debug__
#
# Version 0.01 08/04/2010:  Starting
# ####################################################################################################################
import sys, os
import logging
import logging.config # obbligatorio altrimenti da' l'errore: <'module' object has no attribute 'config'>


# ---- Note riguardo lo STACK Trace ----
# ---- http://blog.dscpl.com.au/2015/03/generating-full-stack-traces-for.html
import inspect

gPackageQualifiers = 0
    # ========================================================
    # - INIT del log. Chiamato solo dal MAIN program
    # ========================================================
def initLogger(loggerFile, package, packageQualifiers=2):
    global gPackageQualifiers
    gPackageQualifiers = packageQualifiers

    try:
        logging.config.fileConfig(loggerFile, disable_existing_loggers=False)
    except Exception as why:
        print("{0} - ERROR in file: {1}".format(str(why), loggerFile))
        sys.exit(1)

    logger      = logging.getLogger(package)
    savedLevel  = logger.getEffectiveLevel()
    logger.setLevel(logging.INFO)
    for i in range(1,10):   logger.info(' ')
    for i in range(1,5):    logger.info('-'*40 + 'Start LOGging' + '-'*20)
    logger.setLevel(savedLevel)
    logFileName = logging.getLoggerClass().root.handlers[0].baseFilename
    return logFileName


    # ========================================================
    # - SetUp del log. Chiamato dai singoli moduli.
    # ========================================================
def setLogger(gv, callerLevel=1, package=None):
    global gPackageQualifiers
    if not package:
        caller      = inspect.stack()[callerLevel]
        programFile = caller[1]     # full name
        lineNumber  = caller[2]
        funcName    = caller[3]
        lineCode    = caller[4]

        fname       = os.path.basename(programFile).split('.')[0]
        package = fname + '.' + funcName


        # ------------------------------------------------
        # - del package cerchiamo di prendere
        # - solo gli ultimi gPackageQualifiers.
        # ------------------------------------------------
    packageHier = package.split('.')
    pkgName  = ('.'.join(packageHier[-gPackageQualifiers:]))

    logger = logging.getLogger(pkgName)
    return logger

#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# 2012-10-10    -   Aggiunto TIMEOUT parameter

import math

# ####################################################################################################
# Due metodi:
#   import platform;    platform.node()
#   import socket;      socket.gethostname()
# ####################################################################################################

def angle (a, b, c):
    return math.degrees(math.acos((b**2 + a**2 -c**2)/(2.0 * a * b)))


def pitagoraIpotenusa(catA, catB):
    ipotenusa = math.sqrt(catA*catA + catB*catB)
    return ipotenusa

def pitagoraCateto(ipot, cateto):
    catetoX = math.sqrt(ipot*ipot - cateto*cateto)
    return catetoX


    # http://stackoverflow.com/questions/14410484/solve-triangle-using-cosine-in-python
    # http://en.wikipedia.org/wiki/Law_of_cosines


if __name__ == "__main__":
    latoA=40
    latoB=120
    latoC=126.491106407
    ipot=latoC

    if latoA == 0:
        pitagoraCateto(ipot, latoB)
    elif latoB == 0:
        pitagoraCateto(ipot, latoA)
    elif latoC == 0:
        pitagoraIpotenusa(latoA, latoB)


    angoloC = angle(latoA, latoB, latoC)
    angoloA = angle(latoB, latoC, latoA)
    angoloB = angle(latoC, latoA, latoB)

    assert angoloA + angoloB + angoloC == 180.0

    print("%-30s: %-20s - %s: %s" % ( "LatoA       ", latoA,   "Angolo opposto", angoloA))
    print("%-30s: %-20s - %s: %s" % ( "LatoB       ", latoB,   "Angolo opposto", angoloB))
    print("%-30s: %-20s - %s: %s" % ( "LatoC (ipot)", latoC,   "Angolo opposto",  angoloC))


    # print "%-30s: %s   - Angolo opposto: %s°" % ( "Ipotenusa LatoC", latoC),;   print "%-30s: %s" % ( "AngoloC (opposto latoA)", angoloA)
    # print "%-30s: %s   - Angolo opposto: %s°" % (  "catetoA LatoA", latoA), ;   print "%-30s: %s" % ( "AngoloC (opposto latoC)", angoloC)
    # print "%-30s: %s   - Angolo opposto: %s°" % (  "catetoB LatoB", latoB), ;  print "%-30s: %s" % ( "AngoloC (opposto latoB)", angoloB)







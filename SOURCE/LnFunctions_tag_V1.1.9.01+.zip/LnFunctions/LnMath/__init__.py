# outer __init__.py
# -*- coding: iso-8859-1 -*-


# from GetHttpPage         import getHttpPage
# from GetHostName           import getHostName


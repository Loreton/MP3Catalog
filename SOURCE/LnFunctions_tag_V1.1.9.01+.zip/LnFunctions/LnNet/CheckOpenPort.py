#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#

import socket


# ####################################################################################################
# Due metodi:
#   import platform;    platform.node()
#   import socket;      socket.gethostname()
# ####################################################################################################

def checkOpenPort(gv, host, port):
    logger = gv.LN.logger.setLogger(gv, pkgName=__name__)
    calledBy    = gv.LN.sys.calledBy

    logger.debug('entered - [called by:%s]' % (calledBy(1)))

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    result = sock.connect_ex((host, port))
    sock.close()

    return result == 0


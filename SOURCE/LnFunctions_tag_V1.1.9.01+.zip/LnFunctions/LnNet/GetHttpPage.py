#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# 28/02/2015 - Aggiunto il parametro di timeOUT

import pprint
import socket
import os

try:
    import httplib2
except ImportError as why:
    print ("----- Loreto IMPORT ERROR ---------")
    print ("-       {0}".format(why))
    print ("-       Il modulo {0} potrebbe non funzionare correttamente!".format(__name__))
    print ("-----------------------------------")
    pass


def getHttpPage(gv, URL, URI='', dataType='TXT', timeOUT=10, removeTAG=False, saveToFile=False, authTYPE=None, SSL=False, console=True):
    logger = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))
    Indent = ' '*8
    TextExtensions  = ['TXT', 'INI', 'ASC', 'SH', 'HTML']

        # -----------------------------------------------------------------------------
        # - non inseriamo il contenuto della pagina nella struttura
        # - in quanto essendo molto variabile, darebbe errore il printDictionary
        # -----------------------------------------------------------------------------
    gv.HTTP.RESP        = ''                            # Risposta dell'HTTP
    gv.HTTP.PAGE        = 'vedi variabile dedicata'     # contenuto della pagina
    gv.HTTP.ERROR       = False                         # indica se abbiamo avuto un errore
    gv.HTTP.statusMSG   = ''                            # Mio messaggio per chiarire l'errore
    gv.HTTP.statusCODE  = 9999                          # Mio messaggio per chiarire l'errore

    # eliminiamo dupliacted slash
    URI = URI.strip().replace('//', '/')
    if SSL:
        myURL = 'https://' + URL.strip() + URI
        h = httplib2.Http(".cache", disable_ssl_certificate_validation=True)
    else:
        myURL = 'http://' + URL.strip() + URI
        # h = httplib2.Http(".cache", timeout=timeOUT)
        h = httplib2.Http(timeout=timeOUT)                     # Non usare la cache ma usa timeOut



    myURI = '/' + myURL.split('/',3)[3]               # prende solo la URI
    if authTYPE == 'BASIC': h.add_credentials('ciaos', 'xyz') # Basic authentication

    logger.info("dataType: {}".format(dataType))
    logger.info("URL:      {0}".format(myURL))

    if console:
        msg = "\n Renaming remote file...:" if 'wsgi?::action=rename' in myURL else "\n URL...:"
        print(gv.LN.cCYAN + msg)
        # print(Indent + gv.LN.cYELLOW + "{0}".format(myURL), end="") # NO NLine
        print(Indent + gv.LN.cYELLOW + "{0}".format(myURL))

        # ===========================
        # = Connecting
        # ===========================
    contentType = None
    content, respFMTed, ERROR, statusCODE = '', '', True, 9999
    try:
        resp, content   = h.request(myURL, "GET")

        # resp, content   = h.request(myURL, "GET")
        statusCODE      = resp.status
        pp              = pprint.PrettyPrinter(indent=4, width=10)
        respFMTed       = pp.pformat(resp).split('\n')

            # forse non è affidabile
        # if "'content-type': 'text/plain'" in str(resp): contentType = 'text/plain'

            # non tutto viene catturato dal try:
        if str(statusCODE).startswith('2'):
            statusMSG = '{} - OK'.format(statusCODE)
            ERROR = False
            for line in respFMTed: logger.debug(line)

        else:
            statusMSG = '{} - ERROR'.format(statusCODE)
            for line in respFMTed: logger.error(line)

    except socket.gaierror as e:
        statusMSG = ' {}'.format(e)

    except httplib2.ServerNotFoundError as e:
        statusMSG = ' {}'.format(e)

    except ConnectionRefusedError as e:
        statusMSG = ' {}'.format(e)

    except Exception as e:
        statusMSG = ' {}'.format(e)

    if ERROR:
        print()   # per spegnere il precedente end=''
        if statusCODE == 404:
            statusMSG = '   The server has not found anything matching the URI given.'

        logger.error(statusMSG)
        if console: print(Indent + gv.LN.cERROR + statusMSG)

    else:
        logger.info("STATUS-MSG: " + statusMSG)
        if console:
            # print(Indent + gv.LN.cYELLOW + statusMSG)
            print(Indent + '  rCode: [{}]'.format(statusMSG))

            # Se è in formato bytes convertiamola in STRIGN
        # if contentType == 'text/plain':
        #     logger.info("content-type: " + contentType)
        #     content = content.decode(encoding='UTF-8')

        if dataType.strip().upper() in TextExtensions and type(content) == bytes:
            logger.info("content-type: " + dataType)
            content = content.decode(encoding='UTF-8')

        if removeTAG:
            content = gv.LN.net.removeHtmlMarkUp(content)

        if saveToFile:
            if saveToFile == True:
                # destDir     = os.path.dirname(myURI)
                destDir     = '/tmp/getHttpPage'
                fName       = os.path.basename(myURI)
                saveToFile  = os.path.join(destDir, fName)
            else:                           #saveToFile contiene il nome:
                destDir = os.path.dirname(saveToFile)

            if not os.path.isdir(destDir): os.makedirs(destDir)
            errMSG = gv.LN.file.writeFile(gv, saveToFile, content)
            if errMSG:
                ERROR       = True
                statusCODE  = 9999
                statusMSG   = errMSG
                logger.error(errMSG)


    gv.HTTP.RESP        = respFMTed                 # Risposta dell'HTTP (in formato LIST)
    gv.HTTP.ERROR       = ERROR                     # indica se abbiamo avuto un errore
    gv.HTTP.statusMSG   = statusMSG                 # Mio messaggio per chiarire l'errore
    gv.HTTP.statusCODE  = statusCODE                # Mio messaggio per chiarire l'errore



    logger.info('exiting - [called by:{}]'.format(calledBy(1)))
    return gv.HTTP, content




# #################################################################
# #  link:  http://stackoverflow.com/questions/4998629/python-split-string-with-multiple-delimiters
# #  splitString with multiple delimiters
# #  delimiters:    LIST of delimiters
# #################################################################

from   types import *                     # per StringType, etc
def getDelimitedString(string, delimiters, maxsplit=3):
    import re

    regexPattern = '|'.join(map(re.escape, delimiters))

    return re.split(regexPattern, string, maxsplit)



import xml
import xml.etree
import xml.etree.ElementTree as XML

def remove_tags(text):
    ''.join(XML.fromstring(text).itertext())


def remove_html_markup(s):
    tag = False
    quote = False
    out = ""

    for c in s:
            if c == '<' and not quote:
                tag = True
            elif c == '>' and not quote:
                tag = False
            elif (c == '"' or c == "'") and tag:
                quote = not quote
            elif not tag:
                out = out + c

    return out


temp =''
s = ' '
def remove_strings(text):
    global temp
    if text == '':
        return temp

    start   = text.find('<')
    end     = text.find('>')
    if start == -1 and end == -1 :
        temp = temp + text
    return temp

    newstring = text[end+1:]
    fresh_start = newstring.find('<')
    if newstring[:fresh_start] != '':
        temp += s+newstring[:fresh_start]

    remove_strings(newstring[fresh_start:])

    return temp




if __name__ == "__main__":
    import sys
    string= '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\\n<html><head>\\n<title>404 Not Found</title>\\n</head><body>\\n<h1>Not Found</h1>\\n<p>The requested URL /xJBossWEB/management/management was not found on this server.</p>\\n</body></html>\\n\''
    xx =  getDelimitedString(string, ['<body>', 'Found</h1>'], maxsplit=0)
    print(xx[1])
    # xx =  remove_tags(string)
    # xx =  remove_strings(string)
    xx =  remove_html_markup(string)
    error, page = getHttpPage('esil904.ac.bankit.it/V621/Machines/SEFALD93/')
    print(xx)
    sys.exit()

    error, page = getHttpPage('www.google.it')
    if not error: print(page)
    print()
    print('..........................')

    error, page = getHttpPage(URL='sefalf97.utenze.bankit.it', URI='/management?recursive=true&include-runtime=true')
    if not error: print(page)
    print()
    print('..........................')

    error, page = getHttpPage(URL='sefaln43.utenze.bankit.it', URI='/xJBossWEB/management/management?operation=resource&include-runtime=true&recursive&json.pretty', authTYPE='BASIC')
    if not error: print(page)
    print('..........................')
    sys.exit()


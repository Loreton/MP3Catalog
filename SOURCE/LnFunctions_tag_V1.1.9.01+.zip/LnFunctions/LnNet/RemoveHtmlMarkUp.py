#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#

######################################################
# # removeHtmlMarkUP(text)
######################################################
def removeHtmlMarkUp(text):
    tag = False
    quote = False
    out = ""

    for c in text:
        if c == '<' and not quote:
            tag = True
            out = out + ' '             # add a blank between fields. Verify if it's OK for you
        elif c == '>' and not quote:
            tag = False
        elif (c == '"' or c == "'") and tag:
            quote = not quote
        elif not tag:
            # print (type(c), c)
            # out = out + str(c)
            out = out + c
    return out


'''
def prova(gv):
    error, page = gv.LN.net.getHttpPage(gv, 'esil904.ac.bankit.it/V621/Machines/SEFALD93/')
    print (page)
    xx =  gv.LN.net.removeHtmlMarkUp(page)
    print (xx)
    items = xx.split('\n')
    # print (items)
    for item in items:
        tokens = item.split()
        if len(tokens) >= 1:
            name = tokens[0]
            if name.endswith('.ini'):
                print (name)
'''
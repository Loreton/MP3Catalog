#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#


import httplib2
import pprint
def getHttpPage(myURL, authTYPE=None):
    h = httplib2.Http(".cache", disable_ssl_certificate_validation=True)

    if authTYPE == 'BASIC':
        h.add_credentials('f602250', 'may45may') # Basic authentication

    resp, content = h.request('http://' + myURL, "GET")
    statusCODE = resp.status

    if statusCODE == 200:
        statusMSG = '200 OK'
    elif statusCODE == 503:
        statusMSG = '503 Service Unavailable'
    elif statusCODE == 404:
        statusMSG = '404 Not Found - The server has not found anything matching the Request-URI'
    else:
        statusMSG = str(statusCODE) + ' Unknown error'

    # pp = pprint.PrettyPrinter(indent=4);    pp.pprint(resp)
    # pprint.pprint(resp)
    print ("    URL: {0}".format(myURL))
    print ("        STATUS {0:20}".format(statusMSG))
    return content


if __name__ == "__main__":
    page = getHttpPage('sefaln43.utenze.bankit.it/JBossWEB/management/management?operation=resource&include-runtime=true&recursive&json.pretty', authTYPE='BASIC')
    page = getHttpPage('sefalf97.utenze.bankit.it/management?recursive=true&include-runtime=true')
    # page = getHttpPage2('esil588')
    # print(page)
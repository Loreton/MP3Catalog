#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# https://code.google.com/p/httplib2/wiki/Examples
#
# 28/02/2015 - Aggiunto il parametro di timeOUT

import httplib2
import pprint
import socket
import os

# import httplib
gURL='jboss-swrepo.utenze.bankit.it/jboss/wsgiTest'
filename = 'curl_Loreto_1K.txt'

def upload_image_to_url():

    f = open(filename, "rb")
    chunk = f.read()
    f.close()

    headers = {
        "Content−type": "application/octet−stream",
        "Accept": "text/plain"
    }

    # conn = httplib2.HTTPConnection(gURL)
    conn = httplib2.Http()                     # Non usare la cache ma usa timeOut
    # conn.request("POST", "/uploaddemo/files/", chunk)
    conn.request(gURL, "POST", "/uploaddemo/files/", chunk, headers)

    response    = conn.getresponse()
    remote_file = response.read()
    conn.close()
    # print (remote_file)

upload_image_to_url()
sys.exit()



def uploadFile(URL, URI='', dataType='TXT', timeOUT=10, authTYPE=None, SSL=False, console=True):
    httplib2.debuglevel = 0

        # -----------------------------------
        # - preparazione della URL
        # -----------------------------------
    URI = URI.strip().replace('//', '/')
    if SSL:
        myURL = 'https://' + URL.strip() + URI
        conn = httplib2.Http(".cache", disable_ssl_certificate_validation=True)
    else:
        myURL = 'http://' + URL.strip() + URI
        conn = httplib2.Http(cache=None, timeout=timeOUT)                     # Non usare la cache ma usa timeOut

    myURI = '/' + myURL.split('/',3)[3]               # prende solo la URI
    if authTYPE == 'BASIC': conn.add_credentials('ciaos', 'xyz') # Basic authentication

    print("dataType: {}".format(dataType))
    print("Getting URL: {0}".format(myURL))

    if console:
        msg = "\n Renaming remote file...:" if 'wsgi?::action=rename' in myURL else "\n Getting URL...:"
        print(msg)
        print("{0}".format(myURL))

        # ===========================
        # = Connecting
        # ===========================
    contentType = None
    content, respFMTed, ERROR, statusCODE = '', '', True, 9999

    headers         = {'cache-control':'no-cache'}
    data            = {'name': 'fred', 'address': '123 shady lane'}
    headers = {
        'Content-Type': 'application/atom+xml',
        'cache-control':'no-cache'
    }


    # resp, content   = conn.request(myURL, "POST", body="This is text", headers={'content-type':'text/plain'} )

    # resp, content   = conn.request(myURL, "POST", "/uploaddemo/files/", open("curl_Loreto_1K.txt", "rb"), headers=headers)
    resp, content   = conn.request(myURL, "POST", "/uploaddemo/files/", open("curl_Loreto_1K.txt", "rb"))
    statusCODE      = resp.status
    pp              = pprint.PrettyPrinter(indent=4, width=10)
    respFMTed       = pp.pformat(resp).split('\n')



if __name__ == "__main__":
    import sys

    error, page = uploadFile(URL='jboss-swrepo.utenze.bankit.it', URI='/jboss/wsgiTest', console=True)
    if not error: print(page)
    print('..........................')
    sys.exit()


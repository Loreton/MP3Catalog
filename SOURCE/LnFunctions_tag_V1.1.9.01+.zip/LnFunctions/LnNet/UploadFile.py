#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
# https://code.google.com/p/httplib2/wiki/Examples
#
# 28/02/2015 - Aggiunto il parametro di timeOUT

import sys, os
import pprint
import socket

try:
    import httplib2
except ImportError as why:
    print ("----- Loreto IMPORT ERROR ---------")
    print ("-       {0}".format(why))
    print ("-       Il modulo {0} potrebbe non funzionare correttamente!".format(__name__))
    print ("-----------------------------------")
    pass

class LnClass():
    pass

GV = LnClass()

def uploadFile(URL, URI='', fileName=None, timeOUT=10, authTYPE=None, SSL=False, console=True, gv=None):
    Indent      = ' '*8
    if gv:
        logger      = gv.LN.logger.setLogger(gv, package=__name__)
        calledBy    = gv.LN.sys.calledBy
        logger.info('entered - [called by:%s]' % (calledBy(1)))
        indentYELL  = Indent + gv.LN.cYELLOW
        indentERROR = Indent + gv.LN.cERROR
        cCYAN       = gv.LN.cCYAN
    else:
        indentYELL  = Indent
        indentERROR = Indent
        cCYAN       = ' '

    httplib2.debuglevel = 0

        # - catturiamo il nome remote file per farne il display
    try:
        remotePathFileName = URI.split('remotePathFileName=')[1]
        remotePathFileName = remotePathFileName.split(';')[0]
    except Exception as why:
        print (indentERROR + "remotePathFileName parameter is missing:")
        print (indentERROR + "[{0}]".format(URI))
        sys.exit()

        # -----------------------------------
        # - preparazione della URL
        # -----------------------------------
    URI = URI.strip().replace('//', '/')
    if SSL:
        myURL = 'https://' + URL.strip() + URI
        conn = httplib2.Http(".cache", disable_ssl_certificate_validation=True)
    else:
        myURL = 'http://' + URL.strip() + URI
        conn = httplib2.Http(cache=None, timeout=timeOUT)                     # Non usare la cache ma usa timeOut

    # ----- BASILARE ------------------------------
    conn.follow_all_redirects = True
    # ----------------------------------------

    if authTYPE == 'BASIC': conn.add_credentials('ciaos', 'xyz') # Basic authentication

        # ---------------------------------------------------
        # - Lettura del file da inviare
        # ---------------------------------------------------
    try:
        f = open(fileName, "rb")
        chunk = f.read()
        f.close()

    except Exception as e:
        statusMSG = 'ERROR reading local file:{0} - {1}'.format(fileName, str(e))
        print(indentERROR + statusMSG)
        sys.exit()


        # ---------------------------------------------------
        # - Messaggio a Console se richiesto
        # ---------------------------------------------------
    if console:
        if   'wsgi?::action=rename' in myURL:
            msg = "\n Renaming remote file...:"
        elif 'wsgi?::action=upload' in myURL:
            msg = "\n Uploading file...: {0}".format(fileName)
        else:
            msg = "\n Uploading file...:"

        print(cCYAN + msg)
        print(indentYELL + "localFile:  {0}".format(fileName))
        print(indentYELL + "remoteFile: {0}".format(remotePathFileName))

    # print(cCYAN + "Executing HTTP: {0}".format(myURL))
    # print(cCYAN + "Executing HTTP: {0}".format(myURL))
    # print(cCYAN + "Uploading file: ...")


        # ===========================
        # = Connecting
        # ===========================

    headers = {
        # 'Content-Type': 'application/octet-stream',
        'Content-Type': 'multipart/form-data',
        # 'Content-Type': 'application/x-www-form-urlencoded',
        # 'Content-Type': 'application/atom+xml',
        'cache-control':'no-cache'
    }

    resp, content = None, None
    ERROR = True
    try:
        resp, content   = conn.request(myURL, method="POST", body=chunk, headers=headers)
        statusCODE      = resp.status
        statusMSG       = '{0} - OK'.format(statusCODE)

            # non tutto viene catturato dal try:
        if str(statusCODE).startswith('2'):
            ERROR = False
            statusMSG = '{} - OK'.format(statusCODE)
            # for line in respFMTed: logger.debug(line)

        else:
            ERROR = True
            statusMSG = '{} - ERROR'.format(statusCODE)
            # for line in respFMTed: logger.error(line)

    except socket.gaierror as e:
        statusMSG = ' {}'.format(e)

    except httplib2.ServerNotFoundError as e:
        statusMSG = ' {}'.format(e)

    except ConnectionRefusedError as e:
        statusMSG = ' {}'.format(e)

    except Exception as e:
        statusMSG = ' {}'.format(e)



    if console:
        print(Indent + '  rCode: [{}]'.format(statusMSG))



    pp          = pprint.PrettyPrinter(indent=4, width=10)
    respFMTed   = pp.pformat(resp).split('\n')


    GV.RESP        = respFMTed                 # Risposta dell'HTTP (in formato LIST)
    GV.ERROR       = ERROR                     # indica se abbiamo avuto un errore
    GV.statusMSG   = statusMSG                 # Mio messaggio per chiarire l'errore
    GV.statusCODE  = resp.status                # Mio messaggio per chiarire l'errore

    resp.ERROR     = ERROR                      # AGGIUNTA DI LORETO

    return resp, content


if __name__ == "__main__":
    import sys
    fileName = 'p:\Python3\LnFunctions\LnNet\Samples\ping1.py'
    fileName = 'p:\Python3\LnFunctions\LnNet\Samples\curl_Loreto_1M.txt'
    URI='/jboss/wsgiTest'
    URI='/jboss/wsgiTest/?;action=writefile;dir=/Machines/SEFALD93/INSTANCE;filename=initialize.ini;create=False;b64data=ZGF0YSB0byBiZSBlbmNvZGVkCmNpYW8gbG9yZXRv'
    URI='/jboss/wsgiTest/?;action=append;dir=/Machines/SEFALD93/INSTANCE;filename=initialize.ini;create=True;b64data=ZGF0YSB0byBiZSBlbmNvZGVkCmNpYW8gbG9yZXRv'
    URI='/jboss/wsgiTest/?;action=rename;dir=/Machines/SEFALD93/INSTANCE;filename=initialize.ini;newFilename=initialize.ini.renamed'
    URI='/jboss/wsgiTest/?;action=addtoProject;serverDir=/Machines/SEFALD93;prjBaseDir=/Progetti;prjName=ELA-PTG;linkName=SEFALD93'
    URI='/jboss/wsgiTest/?;action=upload;dir=/Machines/SEFALD93/INSTANCE;filename=initialize.ini'
    URI='/jboss/wsgiTest/?;action=upload;remotePathFileName=/Machines/SEFALD93/INSTANCE/ProvaUpload.txt;createPath=True'
    error, content = uploadFile(URL='jboss-swrepo.utenze.bankit.it', URI=URI, console=False, fileName=fileName)
    # print ('..........................')
    # for line in GV.RESP:
    #     print(GV.Indent + line)
    # print (GV.RESP)
    # print ('..........................')
    # print (GV.ERROR)
    print ('..........................')
    print (GV.statusMSG)
    # print ('..........................')
    # print (GV.statusCODE)

    print ('.......... CONTENT ................')
    if isinstance(content, bytes): content = content.decode(encoding='UTF-8')
    for line in content.split('\n'): print (line)

    print ('.......... ERRROR ................')
    for key, val in error.items():
        print (GV.Indent + '{0:<20} : {1}'.format(key, val))


    print ()
    print ()



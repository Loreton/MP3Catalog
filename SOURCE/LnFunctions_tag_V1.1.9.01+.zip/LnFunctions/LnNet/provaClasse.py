#!/usr/bin/python
# -*- coding: iso-8859-15 -*-
#
#                   by Loreto Notarantonio
#

import io

class LnBuffer:

    def __init__(self, strID):
        self.name = strID
        self.buffer = io.StringIO(strID)

    def Write(self, text):
        text = text + '\n'
        try:
            self.buffer.write(text)                       # Python3
        except TypeError:
            self.buffer.write(text.decode('utf8'))      # Python2

    def read(self):
        return self.buffer.getvalue()



if __name__ == "__main__":
    buff1 = LnBuffer('uno')
    buff2 = LnBuffer('due')
    buff1.Write('ciao come stai 11')
    buff2.Write('ciao come stai 21')
    buff1.Write('ciao come stai 12')
    buff2.Write('ciao come stai 22')

    x1 = buff1.read()
    x2 = buff2.read()
    print (x1)
    print (x2)



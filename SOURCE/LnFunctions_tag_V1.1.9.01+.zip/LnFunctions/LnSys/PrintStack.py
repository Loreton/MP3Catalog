#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# see:
#   http://www.diveintopython3.net/strings.htmlno
#   http://stackoverflow.com/questions/14682397/can-somone-explain-how-unicodedata-normalizeform-unistr-work-with-examples
#   byData = unicodedata.normalize('NFKD', data).encode('ascii','ignore')
#                                               by Loreto Notarantonio 2014, August
# ######################################################################################
        # -------------------------------
        # - Display dello STACK
        # -------------------------------
def printStack(gv, stackLevel=99):
    logger    = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy  = gv.LN.sys.calledBy

    for i in reversed(list(range(1, stackLevel))):
        caller = calledBy(i)
        print(gv.LN.cGREEN + "    %s" % (caller))
        # if not 'index out of range' in caller:
        #     print(gv.LN.cGREEN + "    %s" % (caller))


#!/usr/bin/python -O
# -*- coding: iso-8859-15 -*-

import os, sys
import argparse
import textwrap

def myParse01():
    # create the top-level parser
    parser = argparse.ArgumentParser(prog='PROG')
    parser.add_argument('--foo', action='store_true', help='foo help')

    subparsers = parser.add_subparsers(help='sub-command help')

    # create the parser for the "a" command
    parser_a = subparsers.add_parser('a', help='a help')
    parser_a.add_argument('bar', type=int, help='bar help')

    # create the parser for the "b" command
    parser_b = subparsers.add_parser('b', help='b help')
    parser_b.add_argument('--baz', choices='XYZ', help='baz help')


    # parse some argument lists
    x1 = parser.parse_args(['a', '12'])
    x2 = parser.parse_args(['--foo', 'b', '--baz', 'Z'])
    print (x1)
    print (x2)





def myParse():
    # create the top-level parser
    parser = argparse.ArgumentParser(prog='PROG')
    parser.add_argument('--foo', action='store_true', help='foo help')

    subparsers = parser.add_subparsers(help='sub-command help')

    # create the parser for the "a" command
    parser_a = subparsers.add_parser('a', help='a help')
    parser_a.add_argument('bar', type=int, help='bar help')

    # create the parser for the "b" command
    parser_b = subparsers.add_parser('b', help='b help')
    parser_b.add_argument('--baz', choices='XYZ', help='baz help')

    args = parser.parse_args()
    dictID = vars(args)
    print()
    print('     ---- INPUT Parameters Start ---')
    print()
    for key, val in dictID.items():
        print('     {:<20} : {}'.format(key, val))
    print()
    print('     ---- INPUT Parameters End   ---')
    print()


'''
    serviceActionsUPP = [x.upper() for x in serviceActions]
    adminActionsUPP   = [x.upper() for x in adminActions]
    totalActionsUPP   = [x.upper() for x in totalActions]
    # parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter, prog='JBossAdmin', description='JBoss Administration tool.')
    # parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter, prog='JBossAdmin', description='JBoss Administration tool.')
    # parser = argparse.ArgumentParser(formatter_class=argparse.MetavarTypeHelpFormatter, prog='JBossAdmin', description='JBoss Administration tool.')
'''

class LnClass(): pass

import argparse

def myParse2():

    serviceActions  =  ["start", "stop", "status", "showconfig", "restart"]
    adminActions    =  ["deploy", "undeploy", "create", "init", "initialize", "showjson"]
    adminActions    =  adminActions + ["cli"]
    totalActions    =  serviceActions + adminActions

    parser = argparse.ArgumentParser(
        # formatter_class=argparse.RawDescriptionHelpFormatter,     # indicates that description and epilog are already correctly formatted and should not be line-wrapped:
        # formatter_class=argparse.ArgumentDefaultsHelpFormatter,     # automatically adds information about default values to each of the argument help messages
        formatter_class=argparse.RawTextHelpFormatter,            # maintains whitespace for all sorts of help text, including argument descriptions.
        prog='JBossAdmin',
        description='''
            JBoss Administration tool.
            ''',
        usage='''
            %(prog)s
            {}
            '''.format( totalActions),
        epilog='''
                Dimmi cosa vuoi fare
                ... ed io provero
                ''',
        conflict_handler='resolve',
    )

    # subparsers = parser.add_subparsers(help='sub-command help')
    subparsers = parser.add_subparsers(title='subcommands',
                                       description='valid subcommands',
                                       help='additional help')
    batchNameFile     = '/tmp/jbossStart'

    p = LnClass()
    group = parser.add_argument_group("\n --------------- Optional parameters----------------",
                                        ".... Altro testo utile.")

    parser.add_argument('--version', action='version', version='JBossAdmin Version 0.01 - 2014-05-22')

    # p.JBNAME = argparse.ArgumentParser(add_help=False)
    # p.JBNAME.add_argument('JBNAME', type=str, metavar= "Nome dell'istanza di JBoss [JBossName or ALL]")


    parser.add_argument( "-A", "--admin",
                       action="store_true",
                       dest="isADMIN",
                       default=False,
                       help="You may indicate Administration level with the -A option. Default is: [False]")


        # ---------------------------------------------------
        # - parser for the "create" command
        # - OKKIO !!!!!!!!!!!!
        # - metavar con 2 o + BLANK da errore
        # ---------------------------------------------------
    p.start         = subparsers.add_parser('start',        help="initializzazione dell'istanza")
    # p.start         = subparsers.add_parser(parents=[p.JBNAME])
    p.stop          = subparsers.add_parser('stop',         help="initializzazione dell'istanza")
    p.status        = subparsers.add_parser('status',       help="initializzazione dell'istanza")
    p.restart       = subparsers.add_parser('restart',      help="initializzazione dell'istanza")
    p.showconfig    = subparsers.add_parser('showconfig',   help="initializzazione dell'istanza")

    p.create        = subparsers.add_parser('create',       help="creazione dell'istanza")
    p.init          = subparsers.add_parser('init',         help="initializzazione dell'istanza")
    p.deploy        = subparsers.add_parser('deploy',       help="initializzazione dell'istanza")
    p.undeploy      = subparsers.add_parser('undeploy',     help="initializzazione dell'istanza")
    p.showjson      = subparsers.add_parser('showjson',     help="initializzazione dell'istanza")
    p.cli           = subparsers.add_parser('cli',          help="initializzazione dell'istanza")


    p.start.add_argument("JBNAME",              metavar= "Nome dell'istanza di JBoss [JBossName or ALL]")
    p.stop.add_argument("JBNAME",               metavar= "Nome dell'istanza di JBoss [JBossName or ALL]")
    p.status.add_argument("JBNAME",             metavar= "Nome dell'istanza di JBoss [JBossName - DEFAULT=ALL]")
    p.restart.add_argument("JBNAME",            metavar= "Nome dell'istanza di JBoss [JBossName or ALL]")
    p.showconfig.add_argument("JBNAME",         metavar= "Nome dell'istanza di JBoss [JBossName]")

    p.create.add_argument("JBNAME",             metavar= "Nome dell'istanza di JBoss [JBossName]")
    p.init.add_argument("JBNAME",               metavar= "Nome dell'istanza di JBoss [JBossName]")
    p.deploy.add_argument("JBNAME",             metavar= "Nome dell'istanza di JBoss [JBossName - DEFAULT=ALL]")
    p.undeploy.add_argument("JBNAME",           metavar= "Nome dell'istanza di JBoss [JBossName]")
    p.showjson.add_argument("JBNAME",           metavar= "Nome dell'istanza di JBoss [JBossName]")
    p.cli.add_argument("JBNAME",                metavar= "Nome dell'istanza di JBoss [JBossName]")


    p.start.add_argument( "-b", "--batch",
                       action="store_true",
                       dest="BATCH",
                       default=False,
                       required=False,
                       help= "Create a batch script to start JBoss [for debugging] file: {}".format(batchNameFile))

    p.init.add_argument( "-s", "--section",
                       dest="INIT_SECTION",
                       default='',
                       required=True,
                       help="REQUIRED - Indica la sezione che deve essere considerata per l'inizialize.")

    p.init.add_argument( "-p", "--prefix",
                       dest="DEPLOY_PREFIX",
                       default='deploy',
                       required=False,
                       help="Indica la stringa prefisso con cui identificare i file di deploy. [DEFAULT: deploy]")

    p.create.add_argument( "-cf", "--standalone-config",
                       dest="STANDALONE_FILENAME",
                       default='standalone.xml',
                       help="Indica il file di configurazione da prendere in considerazione. [DEFAULT: 'standalone.xml'].")

    p.cli.add_argument('-c', '--command',
                        type=str,
                        dest="CLI_ACTION",
                        default=None,
                        help="Indica l'azione che si desidera eseguire.")



    # o_create = p_create.add_argument_group("--------------- Optional parameters----------------", "Use these options to set debug or other values.")
    # p_create.add_argument("JBNAME",     metavar= "JBossName Nome dell'istanza di JBoss")
    # p_create.add_argument('JB_VERSION', metavar= "Versione di JBoss")
    # p_create.add_argument('--offset',   dest='OFFSET', default=100, metavar= "Offset offset di lavoro")
    # p_create.add_argument('JBNAME',   metavar= "Versione di JBoss")
    # p_create.add_argument('yyy',   metavar= "Versione di JBoss")

    # o_create.add_argument('offset2', type=str, help='offset2 - help')

        # ---------------------------------------------------
        # - parser for the "init" command
        # ---------------------------------------------------
    # p_init.add_argument('section', type=str, help="section - il nome della section contenuta nell'.....")

    # g_init = p_init.add_argument_group("--------------- Optional parameters----------------","Use these options to set debug or other values.")
    # g_init.add_argument('offset2', type=str, help='offset2 - help')





    # parser_cli = subparsers.add_parser('cli', help='cli help')







    # group.add_argument( "-d", "--debug",
    #                    dest="DEBUG",
    #                    # default=False,
    #                    default='NO_DEBUG',
    #                    help="You may indicate a debug status with the -d option [ALL|Setup|net|...]. Default is: [NO_DEBUG]")

    args = parser.parse_args()


    dictID = vars(args)
    print()
    print('     ---- INPUT Parameters Start ---')
    print()
    for key, val in dictID.items():
        print('     {:<20} : {}'.format(key, val))
    print()
    print('     ---- INPUT Parameters End   ---')
    print()




if __name__ == "__main__":
    # myParse()
    myParse2()


# Namespace(bar=12, foo=False)
# Namespace(baz='Z', foo=True)
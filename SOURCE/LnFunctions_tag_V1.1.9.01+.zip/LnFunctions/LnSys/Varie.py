#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# see:
#   http://www.diveintopython3.net/strings.htmlno
#   http://stackoverflow.com/questions/14682397/can-somone-explain-how-unicodedata-normalizeform-unistr-work-with-examples
#   byData = unicodedata.normalize('NFKD', data).encode('ascii','ignore')
#                                               by Loreto Notarantonio 2014, August
# ######################################################################################

def isAscii(s):
    try:
        return all(ord(c) < 128 for c in s)
    except TypeError:
        return False


def lnPrint(string):
    if isAscii(string):
        print(string)
    else:
        print (string.encode('utf-8'))

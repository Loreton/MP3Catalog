#!/usr/bin/python
# -*- coding: iso-8859-1 -*-
#
# Scope:  capire se la stringa è ascii o meno
#                                               by Loreto Notarantonio 2014, August
# ######################################################################################

def printAscii(s):
    try:
        value = all(ord(c) < 128 for c in s)
    except TypeError:
        value = ''

    print(value)
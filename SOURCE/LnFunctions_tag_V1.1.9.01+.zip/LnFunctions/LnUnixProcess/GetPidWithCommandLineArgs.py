#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################

import sys
import subprocess
import os


# #####################################################################
# # Return the PID list if processName is provided
# #####################################################################
def getPidWithCommandLineArgs(gv, PID, exitOnError=False):
    logger      = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy    = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(2)))

    # if gv.OpSys.upper() == 'WINDOWS':
    #     CMD = '%s -iql %s' % (gv.PVEXE, PID)
    # else:
    #     CMD = 'ps -fp %s | tail -1' % (PID)

    command = "ps"
    args    = ['-fp', PID, '|', 'tail', '-1']
    rCode, output, err = gv.LN.proc.runCommand(gv, command, argsList=args, PWAIT=True, exitOnError=True, SHELL=True)

    if rCode:
        if exitOnError:
            gv.LN.sys.exit(gv, 9009, err)
        logger.error('Output: %s' % (err))
    else:
        logger.info('Output: %s' % (output))

    return output





#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################
import sys
import subprocess
import os, platform
import getpass
if platform.system() == 'Linux': import pwd


logger = None

# ###################################################################################################################
# # TESTED 2013-02-11
# # http://docs.python.org/2/library/subprocess.html
# # The shell argument (which defaults to False) specifies whether to use the shell as the program to execute.
# #    shell=True               can be a security hazard if combined with untrusted input
# #    universal_newlines=True  By default, this function will return the data as encoded bytes. This behaviour may be overridden by setting universal_newlines to True.# # Example:
# #    userName                 if SET tentiamo il RunAS
# #    pWAIT                    secondi per il TimeOut
# ###################################################################################################################
# def runCommand(gv, command, RunAsUserNam=None, wkdir=None, argsList=[], PWAIT=0, stdOUTfile=False, exitOnError=False, SHELL=False, fDEBUG=False):
def runCommand(gv, command, userName=None, wkdir=None, argsList=[], PWAIT=0, stdOUTfile=False, exitOnError=False, SHELL=False, fDEBUG=False):
    global logger
    logger = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    if not userName:
        xx  = pwd.getpwuid(os.geteuid())
        userName = xx.pw_name

        # -----------------------------
        # - setting default values
        # -----------------------------
    myEnv   =   None
    if SHELL:
        CMD = command + ' ' + ' '.join(argsList)                      # Join command
    else:
        CMD = [command]
        CMD.extend(argsList)                                # convertiamolo in LIST

    logger.info('executing command: {}'.format(str(CMD)))

    stdIN, stdOUT, stdERR = setSTDOUT(stdOUTfile, exitOnError)          # impostiamo i valori di I/O
    logger.info(""" STDOUT: {}""".format(stdOUT))
    logger.info(""" STDERR: {}""".format(stdERR))
    logger.info('executing command: {}'.format(CMD))

    try:
        user = pwd.getpwnam(userName)       # get RunAS user data
        logger.info('Command will be executed with user: [{}]'.format(user))
            # Copiamo l'attuale ENV ed inseriamo nostre variabili per poi passarle al processo
        myEnv = os.environ.copy()   # e' un dictionary
        myEnv[ 'HOME'     ]   = user.pw_dir
        myEnv[ 'LOGNAME'  ]   = user.pw_name
        myEnv[ 'USER'     ]   = user.pw_name
        myEnv[ 'LORETO'   ]   = "SONO PASSATO"
        if wkdir: myEnv[ 'PWD']   = wkdir
        procID = subprocess.Popen(CMD, shell=SHELL, env=myEnv, preexec_fn=demote(user.pw_uid, user.pw_gid), stdin=stdIN, stdout=stdOUT, stderr=stdERR, bufsize=1, cwd=wkdir, universal_newlines=True)

        #  comando senza RunAS
        # procID = subprocess.Popen(CMD, shell=SHELL, env=myEnv, stdin=stdIN, stdout=stdOUT, stderr=stdERR, bufsize=1, cwd=wkdir, universal_newlines=True)

    except Exception as why:
        gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + str(why), console=True, printStack=True)


        # --------------------------
        # - Controllo processo
        # --------------------------
    rCode, err, out, PID = 0, '', '', None
    try:
        if PWAIT>0:
            logger.info('PWAIT must be considered: {}.'.format(PWAIT))
            procID.wait(timeout=PWAIT)

        rCode   = procID.returncode
        logger.info('rCode: {}.'.format(rCode))
        PID     = procID.pid                # Note that if you set the shell argument to True, this is the process ID of the spawned she
        # print (procID, rCode, PID)

    except subprocess.TimeoutExpired:
        err = "TimedOUT occurred"
        procID.kill()
        out, err = procID.communicate()
        out      = procID.stdout.read()
        err      = procID.stderr.read()
        rCode = 1

    else:
        logger.info('command: {} has been successfully executed.'.format(str(CMD)))
        if procID.stdout:
            out      = procID.stdout.read()
            err      = procID.stderr.read()
            # if (err):
                # print(err)
                # rCode = 1
                # exitOnError = True

    logger.info('RCODE: {}'.format(rCode))
    if fDEBUG:
        logger.debug(""" STDOUT: ----------- \n{}""".format(out))
        logger.debug(""" STDERR: ----------- \n{}""".format(err))

    if exitOnError:
        if rCode:
            gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + err)

    return rCode, out, err



# ====================================================================================
# = demote(user_uid, user_gid)
# =   provvede a creare un oggetto da passare al preexec_fn
# ====================================================================================
def demote(user_uid, user_gid):
    realUID, eUID, savedUID = os.getresuid()         # SAVE dello user corrente
    report_ids("{0:<30} - [{1}]".format('Before setUID',               pwd.getpwuid(eUID)))
    report_ids("{0:<30} - [{1}]".format('Executing setUID with user',  pwd.getpwuid(realUID)))
    report_ids("{0:<30} - [{1}]".format('After setUID',                pwd.getpwuid(eUID)))


        # -------------------------------------------------------------
        # Set user to realUID (qello del login) per fare il setUID
        # Il tutto dovrebbe rimanere nello scope del processo perch*
        # sotto la funzione che segue.
        # -------------------------------------------------------------
    def result():
        report_ids("{0:<30} - [{1}]".format('STARTING demotion', pwd.getpwuid(eUID)))
        os.seteuid(realUID)  # Per l'abilitazione a dare il comando di setUID
        os.setgid(user_gid)
        os.setuid(user_uid)
        report_ids("{0:<30} - [{1}]".format('FINISHED demotion', pwd.getpwuid(eUID)))

    report_ids("{0:<30} - [{1}]".format('After  run', pwd.getpwuid(eUID)))

    return result()

def report_ids(msg):
    logger.info('{} - userName:{}, uid:{}, gid:{}'.format(msg, getpass.getuser(), os.getuid(), os.getgid()))



#############################################################################
# # def setSTDOUT()
#############################################################################
def setSTDOUT(stdOUTfile, exitOnError=False):

    if stdOUTfile:
        logger.info("Run with redirection to: %s" %(stdOUTfile))
            # preparazione per la redirezione output su file
        try:
            f = open(stdOUTfile, 'a')
            logger.info('File: {} as been opened as otuput'.format(stdOUTfile))

        except (IOError) as why:
            msg = textwrap.dedent("""\r
            user {} cannot access file: {}
            {}
            """.format(getpass.getuser(), stdOUTfile, str(why)) )
            logger.error(msg)
            if exitOnError:
                if gv:
                    gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + msg)
                else:
                    sys.exit()

        stdIN, stdOUT, stdERR   =   (subprocess.PIPE, f, f)

    else:
        logger.info("Run with no OUTPUT redirection")
        stdIN, stdOUT, stdERR = (subprocess.PIPE, subprocess.PIPE, subprocess.PIPE)

    return stdIN, stdOUT, stdERR



# ###########################################################
# #             M A I N
# ###########################################################
if __name__ == "__main__":

    command = 'scp -P 22 jboss@esil904:/opt/jbossfs/JBOSS-CONFIG-REPO/V621/Machines/SEFALD93/Sefald93Template.ini /tmp/provaSCP1.txt'; args=[];  TimeOUT=2; SHELL=True

    command = 'sleep';  args=['2'];     TimeOUT=1; SHELL=False
    command = 'ls';     args=['-la'];   TimeOUT=2; SHELL=False
    command = 'scp';    args=['-P', '22', 'jboss@esil904:/opt/jbossfs/JBOSS-CONFIG-REPO/V621/Machines/SEFALD93/Sefald93Template.ini', '/tmp/provaSCP1.txt'];   TimeOUT=2; SHELL=False

    userID = None
    userID = 'jboss'
    print(getpass.getuser())

    print('\n'*3)
    rcode, output, err = runCommand(gv, command, RunAaUserName=userID, wkdir='.', argsList=args, PWAIT=TimeOUT, stdOUTfile=False, exitOnError=False, SHELL=SHELL)
    if rcode != 0:
        print ('rcode   :', rcode)
        print ('err     :', err)
    else:
        print ('output  :', output)



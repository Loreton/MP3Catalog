# outer __init__.py
# -*- coding: iso-8859-1 -*-
import platform

from .RunCommand                 import runCommand
from .GetPidWithCommandLineArgs      import getPidWithCommandLineArgs

# if platform.system() == 'Windows':
#     from .GetPIDsWindows import getPIDsWindows as getPIDs
# else:
#     from .GetPIDsUnix    import getPIDsUnix as getPIDs

from .GetPIDs    import getPIDs
from .GetPIDs    import getPIDsRE

#!/usr/bin/python -O
# -*- coding: iso-8859-15 -*-
# -O Optimize e non scrive il __debug__
#
# http://code.activestate.com/recipes/66062-determining-current-function-name/
# Version 0.01 08/04/2010:  Starting
# ####################################################################################################################
import os
import pwd

# ###################################################################################################################
def getUserName(UID=None):
# ###################################################################################################################

    if not UID:
        UID = os.geteuid()

    user = pwd.getpwuid(os.geteuid()).pw_name
    return user



# ###################################################################################################################
def getUID(UserName=None):
# ###################################################################################################################
    if UserName:
        UID = pwd.getpwnam(UserName).pw_uid
    else:
        UID  = os.geteuid()

    return UID


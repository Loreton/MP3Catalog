#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################
import sys
import os, platform
import getpass

import pwd


def ottieniValori():
    #  https://docs.python.org/3.3/library/os.html
    userLogin           = os.getlogin()
    userLogin           = pwd.getpwuid(os.getuid())[0]
    uid                 = os.getuid()   # current process’s user id
    ruid, euid, suid    = os.getresuid()   # real, effective, and saved user ids
    rgid, egid, sgid    = os.getresgid()   # real, effective, and saved group ids.




# ###################################################################################################################
# # #  https://docs.python.org/3.3/library/os.html
# # #  userName:    nome dell'utente di cui si vuole il setUID
# # #  uid     :    uid dell'utente di cui si vuole il setUID
# # #  None    :    se userName==None e uid==None allora viene ppreso il SAVED-UID
# #
# #         gv.LN.sys.setUID(gv, gv.JBOSS.userName, exitOnError=False)
# #         gv.LN.sys.setUID(gv, uid=48, exitOnError=True)
# #         gv.LN.sys.setUID(gv)
# ###################################################################################################################
def setUID_OK(gv, userName=None, uid=None, exitOnError=False):
    global TAByel, TABerr, TAB

    logger = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    TAByel      = gv.LN.cYELLOW + ' '*8
    TABerr      = gv.LN.cERROR + ' '*8
    TAB         = gv.LN.cGREEN + ' '*8


    ruid, euid, suid  = os.getresuid()   # real, effective, and saved user ids

        # ------------------------------
        # - catturiamo lo UID
        # ------------------------------
    if userName != None:
        reqUID = pwd.getpwnam(userName).pw_uid
    elif uid != None:
        reqUID = uid
    else:
        reqUID = ruid                           # preleva il REAL-UID
        # reqUID = suid                           # preleva il SAVED-UID


    logger.info('')
    msg = 'Requested setUID for username:[{}:{}]'.format(pwd.getpwuid(reqUID).pw_name, reqUID)
    logger.info(TAB + msg)
    msg = 'currUser:[{}:{}] ruid:{} euid:{} suid:{} '.format(pwd.getpwuid(os.getuid()).pw_name, os.geteuid(), ruid, euid, suid)
    logger.info(TAB + msg)

        # --------------------------------------------
        # - Se il current euid!=0  non possiamo
        # - fare il setUID per un altro user
        # - Switch temporaneo su root per permetterlo
        # ---------------------------------------------
    rCode = 0

    if euid != 0 and euid != reqUID:
        rCode = processSetUid(gv, 0, exitOnError)

    if rCode == 0:
        rCode = processSetUid(gv, reqUID, exitOnError)

    return rCode



#################################################
#
#################################################
def processSetUid(gv, reqUID, exitOnError=True):
    logger = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    try:
        reqGID = pwd.getpwuid(reqUID).pw_gid
        os.setegid(reqGID)     # mantenere l'ordine GID-UID
        os.seteuid(reqUID)     # mantenere l'ordine GID-UID
        msg = 'After  setUID: username:{}, euid:{}, egid:{}'.format(pwd.getpwuid(os.geteuid()).pw_name, os.geteuid(), os.getegid())
        logger.info(TAB + msg)
        retVal = 0

    except Exception as why:
        errMsg = "setUID({}) - {} - Permissions Error".format(pwd.getpwuid(reqUID).pw_name, str(why))
        logger.error(TABerr + errMsg)
        for line in sys.exc_info():
            logger.info (TAByel + str(line))
        if exitOnError:
            gv.LN.exit(gv, 7002, TAB + errMsg, console=False)
        retVal = 1

    return retVal



#################################################
#
#################################################
def setUID(gv, userName=None, reqUID=None, exitOnError=False):
    logger = gv.LN.logger.setLogger(gv, package=__name__)
    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

    TAByel      = gv.LN.cYELLOW + ' '*8
    TABerr      = gv.LN.cERROR + ' '*8
    TAB         = gv.LN.cGREEN + ' '*8
        # ------------------------------
        # - catturiamo lo UID
        # ------------------------------
    if reqUID == None:
        if userName != None:
            reqUID = pwd.getpwnam(userName).pw_uid
        else:
            return 1

    try:
        reqGID = pwd.getpwuid(reqUID).pw_gid
        os.setegid(reqGID)     # mantenere l'ordine GID-UID
        os.seteuid(reqUID)     # mantenere l'ordine GID-UID
        msg = 'After  setUID: username:{}, euid:{}, egid:{}'.format(pwd.getpwuid(os.geteuid()).pw_name, os.geteuid(), os.getegid())
        logger.info(TAB + msg)
        retVal = 0

    except Exception as why:
        errMsg = "setUID({}) - {} - Permissions Error".format(pwd.getpwuid(reqUID).pw_name, str(why))
        logger.error(TABerr + errMsg)
        for line in sys.exc_info():
            logger.info (TAByel + str(line))
        if exitOnError:
            gv.LN.exit(gv, 7002, TAB + errMsg, console=False)
        retVal = 1

    return retVal









# outer __init__.py
# -*- coding: iso-8859-1 -*-

import platform

# if platform.system() == 'Windows':
    # pass
# else:
from .GetUID                  import getUserName
from .GetUID                  import getUID
from .SetUID                   import setUID

from .ChMod                   import chMod
from .ChOwn                   import chOwn

from .RunCommand                    import runCommand
from .GetPidWithCommandLineArgs     import getPidWithCommandLineArgs
from .GetPIDs    import getPIDs
from .GetPIDs    import getPIDsRE       # regExpressions

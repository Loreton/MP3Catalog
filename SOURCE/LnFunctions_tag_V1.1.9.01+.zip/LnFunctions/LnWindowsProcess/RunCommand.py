#!/usr/bin/python -O
# -*- coding: iso-8859-1 -*-
# -*- coding: latin-1 -*-
#                                               by Loreto Notarantonio 2013, February
# ######################################################################################
import sys
import subprocess
import os, platform
import getpass
if platform.system() == 'Linux': import pwd

class LnStructure(): pass


# ###################################################################################################################
# # TESTED 2013-02-11
# # http://docs.python.org/2/library/subprocess.html
# # The shell argument (which defaults to False) specifies whether to use the shell as the program to execute.
# #    shell=True               can be a security hazard if combined with untrusted input
# #    universal_newlines=True  By default, this function will return the data as encoded bytes. This behaviour may be overridden by setting universal_newlines to True.# # Example:
# #    userName                 Se NOT None allora tentiamo il runAS
# #    pWAIT                    secondi per il TimeOut
# ###################################################################################################################
def runCommand(gv, command, wkdir=None, argsList=[], userName=None, PWAIT=0, stdOUTfile=False, exitOnError=False, SHELL=False, fDEBUG=False):
    global logger
    logger = gv.LN.logger.setLogger(gv, package=__name__)


    calledBy = gv.LN.sys.calledBy
    logger.info('entered - [called by:%s]' % (calledBy(1)))

        # -----------------------------
        # - setting default values
        # -----------------------------
    RUNAS   = True if userName else False
    env     =   None
    CMD     = [command];  CMD.extend(argsList)                                # convertiamolo in LIST
    if SHELL: CMD = command + ' ' + ' '.join(argsList)            # Join command
    logger.info('executing command: {}'.format(str(CMD)))

    stdIN, stdOUT, stdERR = setSTDOUT(stdOUTfile, exitOnError)          # impostiamo i valori di I/O
    logger.info(""" STDOUT: {}""".format(stdOUT))
    logger.info(""" STDERR: {}""".format(stdERR))

    report_ids('executing ' + str(CMD))

    user    = getpass.getuser()
    try:
        if RUNAS:
            logger.info('RUNAS required: [{}]'.format(userName))
            user, env = prepareForRunAS(gv, userName, wkdir)
            procID = subprocess.Popen(CMD, shell=SHELL, env=env, preexec_fn=demote(user.UID, user.UID), stdin=stdIN, stdout=stdOUT, stderr=stdERR, bufsize=1, cwd=wkdir, universal_newlines=True)

        else:
            procID = subprocess.Popen(CMD, shell=SHELL, env=env, stdin=stdIN, stdout=stdOUT, stderr=stdERR, bufsize=1, cwd=wkdir, universal_newlines=True)

    except Exception as why:
        gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + str(why), console=True, printStack=True)

        # --------------------------
        # - Controllo processo
        # --------------------------
    rCode, err, out, PID = 0, '', '', None
    try:
        if PWAIT>0: procID.wait(timeout=PWAIT)
        rCode   = procID.returncode
        PID     = procID.pid                # Note that if you set the shell argument to True, this is the process ID of the spawned she
        # print (procID, rCode, PID)

    except subprocess.TimeoutExpired:
        err = "TimedOUT occurred"
        procID.kill()
        out, err = procID.communicate()
        out      = procID.stdout.read()
        err      = procID.stderr.read()
        rCode = 1

    else:
        logger.info('command: {} has been successfully executed.'.format(str(CMD)))
        if procID.stdout:
            out      = procID.stdout.read()
            err      = procID.stderr.read()

    logger.info('RCODE: {}'.format(rCode))
    if fDEBUG:
        logger.debug(""" STDOUT: ----------- \n{}""".format(out))
        logger.debug(""" STDERR: ----------- \n{}""".format(err))

    if exitOnError:
        if rCode:
            gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + err)

    return rCode, out, err


#############################################################################
# = demote(user_uid, user_gid)
# =   provvede a creare un oggetto da passare al preexec_fn
#############################################################################
def demote(user_uid, user_gid):

    try:
        report_ids('befoure setUID')
        os.setgid(user_gid)     # mantenere l'ordine GID-UID
        os.setuid(user_uid)     # mantenere l'ordine GID-UID
        report_ids('after   setUID')

    except PermissionError as why:
        errMsg = "setUID({}) - {}".format(user_uid, str(why))
        logger.error(errMsg)
        sys.exit()

    except:
        errMsg = "setUID({}) - Unexpected error: ", str(sys.exc_info()[0])
        logger.error(errMsg)
        sys.exit()

def report_ids(msg):
    logger.info('username:%s, uid:%d, gid:%d; =  %s' % (getpass.getuser(), os.getuid(), os.getgid(), msg) )

def report_idsWin(msg):
    logger.info('username:%s =  %s' % (getpass.getuser(), msg) )




#############################################################################
# # def setSTDOUT()
#############################################################################
def prepareForRunAS(gv, userName, wkdir):
    user = LnStructure()
    try:
        (user.NAME, user.PASSWD, user.UID, user.GID, user.GECOS, user.HOME_DIR, user.SHELL) = pwd.getpwnam(userName)
    except KeyError as why:
        errMsg = str(why)
        gv.LN.exit(gv, 1099, errMsg)
        # if gv: print (gv.LN.cERROR + errMsg)
        # sys.exit()

        # Copiamo l'attuale ENV ed inseriamo nostre variabili per poi passarle al processo
    env = os.environ.copy()
    env[ 'HOME'     ]   = user.HOME_DIR
    env[ 'LOGNAME'  ]   = user.NAME
    env[ 'USER'     ]   = user.NAME
    env[ 'LORETO'   ]   = "SONO PASSATO"
    if wkdir: env[ 'PWD'      ]   = wkdir

    return user, env

#############################################################################
# # def setSTDOUT()
#############################################################################
def setSTDOUT(stdOUTfile, exitOnError=False):

    if stdOUTfile:
        logger.info("Run with redirection to: %s" %(stdOUTfile))
            # preparazione per la redirezione output su file
        try:
            f = open(stdOUTfile, 'a')
            logger.info('File: {} as been opened as otuput'.format(stdOUTfile))

        except (IOError) as why:
            msg = textwrap.dedent("""\r
            user {} cannot access file: {}
            {}
            """.format(getpass.getuser(), stdOUTfile, str(why)) )
            logger.error(msg)
            if exitOnError:
                if gv:
                    gv.LN.sys.exit(gv, 9001, gv.LN.cERROR + msg)
                else:
                    sys.exit()

        stdIN, stdOUT, stdERR   =   (subprocess.PIPE, f, f)

    else:
        logger.info("Run with no OUTPUT redirection")
        stdIN, stdOUT, stdERR = (subprocess.PIPE, subprocess.PIPE, subprocess.PIPE)

    return stdIN, stdOUT, stdERR

# ###########################################################
# #             M A I N
# ###########################################################
if __name__ == "__main__":

    command = 'scp -P 22 jboss@esil904:/opt/jbossfs/JBOSS-CONFIG-REPO/V621/Machines/SEFALD93/Sefald93Template.ini /tmp/provaSCP1.txt'; args=[];  TimeOUT=2; SHELL=True

    command = 'sleep';  args=['2'];     TimeOUT=1; SHELL=False
    command = 'ls';     args=['-la'];   TimeOUT=2; SHELL=False
    command = 'scp';    args=['-P', '22', 'jboss@esil904:/opt/jbossfs/JBOSS-CONFIG-REPO/V621/Machines/SEFALD93/Sefald93Template.ini', '/tmp/provaSCP1.txt'];   TimeOUT=2; SHELL=False

    userID = None
    userID = 'jboss'
    print(getpass.getuser())

    print('\n'*3)
    rcode, output, err = runCommand(gv, command, userName=userID, wkdir='.', argsList=args, PWAIT=TimeOUT, stdOUTfile=False, exitOnError=False, SHELL=SHELL)
    if rcode != 0:
        print ('rcode   :', rcode)
        print ('err     :', err)
    else:
        print ('output  :', output)



# outer __init__.py
# -*- coding: iso-8859-1 -*-
import platform

# from .RunCommand                 import runCommand
# from .runCommand                 import runCommand_New
# from .runProcess                 import runProcess
# from .runAS                      import runAS
# from .GetPidWithCommandLineArgs      import getPidWithCommandLineArgs

# if platform.system() == 'Windows':
#     from .GetPIDsWindows import getPIDsWindows as getPIDs
# else:
#     from .GetPIDsUnix    import getPIDsUnix as getPIDs

# from .GetPIDs    import getPIDs
